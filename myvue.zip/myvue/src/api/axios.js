// api/axios.js
import axios from "axios";

// 创建 Axios 实例
const instance = axios.create({
  baseURL: "http://localhost:8081/api",
  timeout: 1000,
});

// 用户注册请求
export const registerUser = (user) => {
  return instance.post("/user/register", {
    userName: user.phone,
    password: user.password,
    phone: user.phone,
    email: user.email,
    userType: 1,
  });
};
