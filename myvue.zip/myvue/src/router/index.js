import Vue from "vue";
import Router from "vue-router";
import HomeViews from "@/views/HomeViews.vue";
import JobsViews from "@/views/JobsViews.vue";
import PostJobViews from "@/views/PostJobViews.vue";
import MyJobsViews from "@/views/MyJobsViews.vue";
import MessagesViews from "@/views/MessagesViews.vue";
import ProfileViews from "@/views/ProfileViews.vue";
import ContractView from "@/views/ContractView.vue";
import EnterpriseViews from "@/views/EnterpriseViews.vue";
import LoginView from "@/views/LoginView.vue";
import RegisterView from "@/views/RegisterView.vue";
import JobDetailView from "../views/JobDetailView.vue";

Vue.use(Router);

// 先创建router实例
const router = new Router({
  mode: "history", // 可选，去除URL中的#
  routes: [
    {
      path: "/home",
      name: "Home",
      component: HomeViews,
      meta: {
        title: "首页 - 智慧零工平台",
      },
    },
    {
      path: "/jobs",
      name: "Jobs",
      component: JobsViews,
      meta: {
        title: "找零工 - 智慧零工平台",
      },
    },
    {
      path: "/post-job",
      name: "PostJob",
      component: PostJobViews,
      meta: {
        title: "发布任务 - 智慧零工平台",
      },
    },
    {
      path: "/my-jobs",
      name: "MyJobs",
      component: MyJobsViews,
      meta: {
        title: "我的任务 - 智慧零工平台",
      },
    },
    {
      path: "/messages",
      name: "Messages",
      component: MessagesViews,
      meta: {
        title: "消息中心 - 智慧零工平台",
      },
    },
    {
      path: "/profile",
      name: "Profile",
      component: ProfileViews,
      meta: {
        title: "个人中心 - 智慧零工平台",
      },
    },
    {
      path: "/contractView",
      name: "ContractView",
      component: ContractView,
      meta: {
        title: "合同查看 - 智慧零工平台",
      },
    },
    {
      path: "/enterprise",
      name: "Enterprise",
      component: EnterpriseViews,
      meta: {
        title: "企业服务 - 智慧零工平台",
      },
    },
    {
      path: "/loginview",
      name: "LoginView",
      component: LoginView,
      meta: {
        title: "登录 - 智慧零工平台",
      },
    },
    {
      path: "/registerview",
      name: "RegisterView",
      component: RegisterView,
      meta: {
        title: "注册 - 智慧零工平台",
      },
    },
    {
      path: "/job/:id",
      name: "JobDetailView",
      component: JobDetailView,
      meta: {
        title: "任务详情 - 智慧零工平台",
      },
    },
  ],
});

// 现在可以使用router变量了
router.beforeEach((to, from, next) => {
  if (to.meta.title) {
    document.title = to.meta.title;
  }
  next();
});

// 最后导出router实例
export default router;
