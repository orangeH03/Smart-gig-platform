<template>
  <div id="app">
    <!-- 顶部导航栏 -->
    <nav class="navbar">
      <div class="logo-container">
        <div class="logo">智慧零工平台</div>
      </div>
      <div class="user-actions">
        <router-link to="/loginview" class="login-btn">登录</router-link>
        <span class="divider">/</span>
        <router-link to="/registerview" class="register-btn">注册</router-link>
      </div>
    </nav>

    <!-- 整体布局容器 -->
    <div class="layout-container">
      <!-- 功能侧边栏 -->
      <div class="sidebar">
        <ul class="menu">
          <li>
            <router-link to="/home"><i class="icon-home"></i>首页</router-link>
          </li>
          <li>
            <router-link to="/jobs"
              ><i class="icon-briefcase"></i>找零工</router-link
            >
          </li>
          <li>
            <router-link to="/post-job"
              ><i class="icon-edit"></i>发任务</router-link
            >
          </li>
          <li>
            <router-link to="/my-jobs"
              ><i class="icon-list"></i>我的任务</router-link
            >
          </li>
          <li>
            <router-link to="/messages"
              ><i class="icon-message"></i>消息中心</router-link
            >
          </li>
          <li>
            <router-link to="/profile"
              ><i class="icon-user"></i>个人中心</router-link
            >
          </li>
          <li>
            <router-link to="/contractView"
              ><i class="icon-book"></i>合同模板</router-link
            >
          </li>
          <li>
            <router-link to="/enterprise"
              ><i class="icon-building"></i>企业服务</router-link
            >
          </li>
        </ul>
      </div>

      <!-- 主内容区 -->
      <div class="main-content">
        <router-view />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "App",
  data() {
    return {
      searchQuery: "", // 搜索关键词
    };
  },
  methods: {
    searchJobs() {
      if (this.searchQuery.trim() === "") {
        this.$message.warning("请输入搜索关键词");
        return;
      }
      console.log("搜索关键词:", this.searchQuery);
      // 这里可以调用 API 发起搜索请求
    },
  },
};
</script>

<style>
/* 基础样式 */
:root {
  --primary-color: #409eff;
  --secondary-color: #67c23a;
  --danger-color: #f56c6c;
  --warning-color: #e6a23c;
  --info-color: #909399;
  --text-color: #303133;
  --text-light: #606266;
  --border-color: #dcdfe6;
  --bg-color: #f5f7fa;
  --sidebar-width: 240px;
  --navbar-height: 60px;
  --transition: all 0.3s ease;
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: "PingFang SC", "Microsoft YaHei", sans-serif;
  color: var(--text-color);
  background-color: var(--bg-color);
}

#app {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

/* 导航栏样式 */
.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30px;
  height: var(--navbar-height);
  background: linear-gradient(135deg, #1e88e5, #0d47a1);
  color: white;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  position: relative;
  z-index: 10;
}

.logo-container {
  display: flex;
  align-items: center;
}

.logo {
  font-size: 22px;
  font-weight: bold;
  margin-right: 10px;
}

.user-actions {
  display: flex;
  align-items: center;
  gap: 15px;
}

.user-actions a {
  color: white;
  text-decoration: none;
  font-size: 14px;
  transition: var(--transition);
  padding: 5px 0;
}

.login-btn:hover,
.register-btn:hover {
  opacity: 0.8;
}

.divider {
  opacity: 0.6;
}

.notification:hover {
  background: rgba(255, 255, 255, 0.1);
}

.badge {
  position: absolute;
  top: 2px;
  right: 2px;
  background-color: var(--danger-color);
  color: white;
  border-radius: 50%;
  width: 16px;
  height: 16px;
  font-size: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* 布局容器 */
.layout-container {
  display: flex;
  flex: 1;
  overflow: hidden;
}

/* 侧边栏样式 */
.sidebar {
  width: var(--sidebar-width);
  background: white;
  box-shadow: 2px 0 10px rgba(0, 0, 0, 0.05);
  display: flex;
  flex-direction: column;
  transition: var(--transition);
  z-index: 5;
}

/* 菜单样式 */
.menu {
  list-style: none;
  padding: 10px 0;
  margin: 0;
  flex: 1;
  overflow-y: auto;
}

.menu li {
  margin: 5px 0;
}

.menu li a {
  display: flex;
  align-items: center;
  padding: 12px 20px;
  text-decoration: none;
  color: var(--text-light);
  font-size: 14px;
  transition: var(--transition);
  border-left: 3px solid transparent;
}

.menu li a:hover {
  color: var(--primary-color);
  background-color: rgba(64, 158, 255, 0.1);
}

.menu li a.router-link-active {
  color: var(--primary-color);
  background-color: rgba(64, 158, 255, 0.1);
  border-left-color: var(--primary-color);
  font-weight: 500;
}

.menu li a i {
  margin-right: 10px;
  font-size: 16px;
}

/* 主内容区样式 */
.main-content {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
  background-color: #f0f2f5;
}

/* 图标字体 */
@font-face {
  font-family: "iconfont";
  src: url("//at.alicdn.com/t/font_1234567_abcdefghijk.eot");
  src: url("//at.alicdn.com/t/font_1234567_abcdefghijk.eot?#iefix")
      format("embedded-opentype"),
    url("//at.alicdn.com/t/font_1234567_abcdefghijk.woff2") format("woff2"),
    url("//at.alicdn.com/t/font_1234567_abcdefghijk.woff") format("woff"),
    url("//at.alicdn.com/t/font_1234567_abcdefghijk.ttf") format("truetype"),
    url("//at.alicdn.com/t/font_1234567_abcdefghijk.svg#iconfont") format("svg");
}

.iconfont {
  font-family: "iconfont" !important;
  font-size: 16px;
  font-style: normal;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.icon-home:before {
  content: "\e600";
}
.icon-briefcase:before {
  content: "\e601";
}
.icon-edit:before {
  content: "\e602";
}
.icon-list:before {
  content: "\e603";
}
.icon-message:before {
  content: "\e604";
}
.icon-user:before {
  content: "\e605";
}
.icon-book:before {
  content: "\e606";
}
.icon-building:before {
  content: "\e607";
}
.icon-search:before {
  content: "\e608";
}
.icon-bell:before {
  content: "\e609";
}
.icon-arrow-down:before {
  content: "\e60a";
}

/* 响应式设计 */
@media (max-width: 768px) {
  .sidebar {
    position: fixed;
    left: -100%;
    top: var(--navbar-height);
    bottom: 0;
    z-index: 100;
  }

  .sidebar.active {
    left: 0;
  }

  .main-content {
    margin-left: 0;
  }

  .search-input-round {
    padding: 10px 15px;
    padding-right: 45px;
  }

  .search-btn-round {
    width: 28px;
    height: 28px;
  }

  .icon-feature1:before {
    content: "\e61a";
  }
  .icon-feature2:before {
    content: "\e61b";
  }
  .icon-feature3:before {
    content: "\e61c";
  }
  .icon-plus:before {
    content: "\e61d";
  }
}
</style>
