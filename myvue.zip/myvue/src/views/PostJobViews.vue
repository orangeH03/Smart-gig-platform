<template>
  <div class="post-job-container">
    <h1>发布新任务</h1>
    <form @submit.prevent="submitJob">
      <div class="form-group">
        <label for="title">任务标题</label>
        <input
          type="text"
          id="title"
          v-model="job.title"
          required
          placeholder="请输入任务标题"
        />
      </div>

      <div class="form-group">
        <label for="description">任务描述</label>
        <textarea
          id="description"
          v-model="job.description"
          required
          placeholder="请输入任务描述"
        ></textarea>
      </div>

      <div class="form-group">
        <label for="category">任务分类</label>
        <select id="category" v-model="job.category">
          <option value="">请选择分类</option>
          <option value="开发">开发</option>
          <option value="设计">设计</option>
          <option value="测试">测试</option>
          <option value="运维">运维</option>
        </select>
      </div>

      <div class="form-group">
        <label for="location">工作地点</label>
        <input
          type="text"
          id="location"
          v-model="job.location"
          required
          placeholder="请输入工作地点"
        />
      </div>

      <div class="form-group">
        <label for="salaryRange">薪资范围</label>
        <input
          type="text"
          id="salaryRange"
          v-model="job.salaryRange"
          required
          placeholder="例如：5000-10000"
        />
      </div>

      <div class="form-group">
        <label for="jobType">工作类型</label>
        <select id="jobType" v-model="job.jobType">
          <option value="">请选择工作类型</option>
          <option value="全职">全职</option>
          <option value="兼职">兼职</option>
          <option value="实习">实习</option>
        </select>
      </div>

      <div class="form-group">
        <label for="tags">标签（逗号分隔）</label>
        <input
          type="text"
          id="tags"
          v-model="job.tags"
          placeholder="例如：Vue.js,Node.js"
        />
      </div>

      <button type="submit">发布任务</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      job: {
        title: "",
        description: "",
        category: "",
        location: "",
        salaryRange: "",
        jobType: "",
        tags: "",
      },
    };
  },
  methods: {
    submitJob() {
      // 将标签字符串转换为数组
      this.job.tags = this.job.tags.split(",").map((tag) => tag.trim());

      // 发布任务逻辑（这里可以发送请求到后端）
      console.log("发布的任务信息：", this.job);

      // 清空表单
      this.job = {
        title: "",
        description: "",
        category: "",
        location: "",
        salaryRange: "",
        jobType: "",
        tags: "",
      };

      alert("任务发布成功！");
    },
  },
};
</script>

<style scoped>
.post-job-container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
  background-color: #f9f9f9;
}

h1 {
  text-align: center;
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 15px;
}

label {
  display: block;
  margin-bottom: 5px;
}

input,
textarea,
select {
  width: 100%;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}
</style>
