<template>
  <div class="contract-container">
    <h1>电子合同</h1>
    <div class="contract-section">
      <h2>选择合同模板</h2>
      <el-select v-model="selectedTemplate" placeholder="请选择合同模板">
        <el-option
          v-for="template in templates"
          :key="template.value"
          :label="template.label"
          :value="template.value"
        ></el-option>
      </el-select>
    </div>

    <div class="contract-preview">
      <h2>合同预览</h2>
      <div v-if="selectedTemplate" class="contract-content">
        <h3>{{ selectedTemplate.label }}</h3>
        <p>{{ selectedTemplate.description }}</p>
      </div>
      <div v-else>
        <p>请选择一个合同模板以查看内容。</p>
      </div>
    </div>

    <div class="contract-actions">
      <el-button
        type="primary"
        @click="signContract"
        :disabled="!selectedTemplate"
      >
        签署合同
      </el-button>
    </div>
  </div>
</template>

<script>
export default {
  name: "ContractView",
  data() {
    return {
      selectedTemplate: null,
      templates: [
        {
          value: 1,
          label: "自由职业者服务合同",
          description: "适用于自由职业者与客户之间的服务合同。",
        },
        {
          value: 2,
          label: "项目合作协议",
          description: "适用于多个合作伙伴之间的项目合作协议。",
        },
        {
          value: 3,
          label: "保密协议",
          description: "适用于保护商业机密和敏感信息的保密协议。",
        },
      ],
    };
  },
  methods: {
    signContract() {
      alert(`您已选择签署合同：${this.selectedTemplate.label}`);
    },
  },
};
</script>

<style scoped>
.contract-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.contract-section,
.contract-preview,
.contract-actions {
  margin-bottom: 20px;
}

.contract-content {
  border: 1px solid #ccc;
  padding: 10px;
  border-radius: 8px;
  background-color: #f9f9f9;
}

.contract-actions button {
  padding: 10px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.contract-actions button:hover {
  background-color: #0056b3;
}
</style>
