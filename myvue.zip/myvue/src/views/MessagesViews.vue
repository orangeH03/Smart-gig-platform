<template>
  <div class="chat-container">
    <h1>即时通讯</h1>
    <div class="chat-sidebar">
      <h2>消息列表</h2>
      <ul class="message-list">
        <li
          v-for="message in messages"
          :key="message.id"
          @click="selectMessage(message)"
          :class="{ active: selectedMessage === message }"
        >
          {{ message.sender }}: {{ message.content }}
        </li>
      </ul>
    </div>
    <div class="chat-main">
      <div class="chat-header">
        <h3>{{ selectedMessage?.sender || "选择一个对话" }}</h3>
      </div>
      <div class="chat-content">
        <div
          v-for="msg in selectedMessage?.messages"
          :key="msg.id"
          class="message"
          :class="{ 'message-sent': msg.sender === '我' }"
        >
          <p v-if="msg.type === 'text'">{{ msg.content }}</p>
          <audio v-if="msg.type === 'audio'" controls>
            <source :src="msg.content" type="audio/mpeg" />
            您的浏览器不支持音频播放。
          </audio>
          <video v-if="msg.type === 'video'" controls>
            <source :src="msg.content" type="video/mp4" />
            您的浏览器不支持视频播放。
          </video>
        </div>
      </div>
      <div class="chat-input">
        <input
          type="text"
          v-model="newMessage"
          @keyup.enter="sendMessage"
          placeholder="输入消息..."
        />
        <button @click="sendMessage">发送</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "ChatView",
  data() {
    return {
      messages: [
        {
          id: 1,
          sender: "用户A",
          messages: [
            {
              id: 1,
              type: "text",
              content: "你好，这是文字消息",
              sender: "用户A",
            },
            { id: 2, type: "audio", content: "audio.mp3", sender: "用户A" },
            { id: 3, type: "video", content: "video.mp4", sender: "用户A" },
          ],
        },
        {
          id: 2,
          sender: "用户B",
          messages: [
            {
              id: 4,
              type: "text",
              content: "你好，这是另一条文字消息",
              sender: "用户B",
            },
          ],
        },
      ],
      selectedMessage: null,
      newMessage: "",
    };
  },
  methods: {
    selectMessage(message) {
      this.selectedMessage = message;
    },
    sendMessage() {
      if (this.selectedMessage && this.newMessage.trim()) {
        const newMessage = {
          id: Date.now(),
          type: "text",
          content: this.newMessage.trim(),
          sender: "我",
        };
        this.selectedMessage.messages.push(newMessage);
        this.newMessage = "";
      }
    },
  },
};
</script>

<style scoped>
.chat-container {
  display: flex;
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.chat-sidebar {
  width: 300px;
  border-right: 1px solid #ccc;
  padding: 10px;
}

.message-list {
  list-style: none;
  padding: 0;
}

.message-list li {
  padding: 10px;
  border-bottom: 1px solid #eee;
  cursor: pointer;
}

.message-list li.active {
  background-color: #f0f0f0;
}

.chat-main {
  flex: 1;
  padding: 20px;
}

.chat-header {
  margin-bottom: 20px;
}

.chat-content {
  border: 1px solid #ccc;
  padding: 10px;
  margin-bottom: 20px;
  height: 300px;
  overflow-y: auto;
}

.message {
  margin-bottom: 10px;
}

.message-sent {
  text-align: right;
}

.chat-input {
  display: flex;
  justify-content: space-between;
}

.chat-input input {
  flex: 1;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.chat-input button {
  padding: 10px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.chat-input button:hover {
  background-color: #0056b3;
}
</style>
