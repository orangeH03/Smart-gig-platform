<template>
  <div class="profile-container">
    <h1>个人信息中心</h1>
    <div class="profile-form">
      <el-form :model="user" label-width="120px" ref="userForm">
        <el-form-item label="用户名">
          <el-input v-model="user.username" disabled></el-input>
        </el-form-item>
        <el-form-item label="邮箱">
          <el-input v-model="user.email"></el-input>
        </el-form-item>
        <el-form-item label="手机号">
          <el-input v-model="user.phone"></el-input>
        </el-form-item>
        <el-form-item label="地址">
          <el-input v-model="user.address"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="saveProfile">保存信息</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
export default {
  name: "ProfileView",
  data() {
    return {
      user: {
        username: "张三", // 模拟登录用户的信息
        email: "zhangsan@example.com",
        phone: "13800138000",
        address: "北京市朝阳区",
      },
    };
  },
  methods: {
    saveProfile() {
      // 模拟保存用户信息到后端
      console.log("保存的用户信息：", this.user);
      this.$message.success("个人信息已更新！");
    },
  },
};
</script>

<style scoped>
.profile-container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
  background-color: #f9f9f9;
}

h1 {
  text-align: center;
  margin-bottom: 20px;
}

.profile-form {
  margin-top: 20px;
}

.el-form-item {
  margin-bottom: 15px;
}

.el-button {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.el-button:hover {
  background-color: #0056b3;
}
</style>
