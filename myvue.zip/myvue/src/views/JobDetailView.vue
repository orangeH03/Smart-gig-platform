<template>
  <div class="job-detail-container">
    <h1>{{ job.title }}</h1>
    <p>{{ job.description }}</p>
    <div class="job-info">
      <p><strong>薪资范围：</strong>{{ job.salaryRange }}</p>
      <p><strong>工作地点：</strong>{{ job.location }}</p>
    </div>
    <div class="job-actions">
      <el-button type="primary" @click="applyJob">申请任务</el-button>
    </div>
  </div>
</template>

<script>
export default {
  name: "JobDetailView",
  data() {
    return {
      job: {},
    };
  },
  created() {
    this.fetchJobDetails();
  },
  methods: {
    fetchJobDetails() {
      const jobId = this.$route.params.id;
      // 模拟从后端获取任务详情
      const jobs = [
        {
          id: 1,
          title: "前端开发任务",
          description: "需要一个 Vue.js 专家来开发一个新项目",
          salaryRange: "8000-15000",
          location: "北京",
        },
        {
          id: 2,
          title: "UI/UX 设计任务",
          description: "设计一个新产品的用户界面",
          salaryRange: "7000-12000",
          location: "上海",
        },
        {
          id: 3,
          title: "后端开发任务",
          description: "需要一个 Node.js 开发者来优化后端服务",
          salaryRange: "9000-16000",
          location: "广州",
        },
      ];

      this.job = jobs.find((job) => job.id == jobId) || {};
    },
    applyJob() {
      alert(`您已申请任务：${this.job.title}`);
    },
  },
};
</script>

<style scoped>
.job-detail-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
  background-color: #f9f9f9;
}

h1 {
  font-size: 24px;
  margin-bottom: 15px;
}

p {
  font-size: 16px;
  margin-bottom: 20px;
}

.job-info {
  margin-bottom: 20px;
}

.job-info p {
  font-size: 14px;
  color: #666;
}

.job-actions {
  text-align: center;
}

.job-actions button {
  padding: 10px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.job-actions button:hover {
  background-color: #0056b3;
}
</style>
