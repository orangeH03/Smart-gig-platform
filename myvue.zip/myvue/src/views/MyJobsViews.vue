<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <title>MyJobsViews</title>
  </head>
  <body></body>
</html>
