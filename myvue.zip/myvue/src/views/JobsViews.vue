<template>
  <div class="jobs-container">
    <!-- 搜索和筛选区域 -->
    <div class="search-filter-section">
      <div class="search-box">
        <el-input
          v-model="searchQuery"
          placeholder="搜索零工职位、技能或关键词..."
          clearable
          @clear="handleSearchClear"
          @keyup.enter="handleSearch"
        >
          <template #append>
            <el-button icon="el-icon-search" @click="handleSearch" />
          </template>
        </el-input>
      </div>

      <div class="filter-area">
        <el-row :gutter="20">
          <el-col :span="6">
            <el-select
              v-model="filter.category"
              placeholder="职位分类"
              clearable
              @change="handleFilterChange"
            >
              <el-option
                v-for="item in jobCategories"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-col>
          <el-col :span="6">
            <el-select
              v-model="filter.location"
              placeholder="工作地点"
              clearable
              @change="handleFilterChange"
            >
              <el-option
                v-for="item in locations"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-col>
          <el-col :span="6">
            <el-select
              v-model="filter.salaryRange"
              placeholder="薪资范围"
              clearable
              @change="handleFilterChange"
            >
              <el-option
                v-for="item in salaryRanges"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-col>
          <el-col :span="6">
            <el-select
              v-model="filter.jobType"
              placeholder="工作类型"
              clearable
              @change="handleFilterChange"
            >
              <el-option
                v-for="item in jobTypes"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-col>
        </el-row>
      </div>
    </div>

    <!-- 工作列表 -->
    <div class="job-list-section">
      <div class="job-list-header">
        <h2>找到 {{ filteredJobs.length }} 个零工职位</h2>
        <el-select
          v-model="sortOption"
          placeholder="排序方式"
          @change="handleSortChange"
        >
          <el-option
            v-for="item in sortOptions"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </div>

      <div class="job-list">
        <div
          v-for="job in paginatedJobs"
          :key="job.id"
          class="job-card"
          @click="viewJobDetail(job.id)"
        >
          <div class="job-card-header">
            <h3>{{ job.title }}</h3>
            <span class="salary">{{ job.salary }}</span>
          </div>
          <div class="job-card-body">
            <div class="job-meta">
              <span
                ><i class="el-icon-location-outline"></i>
                {{ job.location }}</span
              >
              <span><i class="el-icon-time"></i> {{ job.postTime }}</span>
            </div>
            <div class="job-description">
              {{ job.description }}
            </div>
            <div class="job-tags">
              <el-tag
                v-for="(tag, index) in job.tags"
                :key="index"
                size="small"
                :type="tagTypes[index % tagTypes.length]"
              >
                {{ tag }}
              </el-tag>
            </div>
          </div>
          <div class="job-card-footer">
            <el-button
              type="primary"
              size="small"
              @click.stop="applyJob(job.id)"
            >
              立即申请
            </el-button>
          </div>
        </div>
      </div>

      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          :current-page="currentPage"
          :page-size="pageSize"
          :total="filteredJobs.length"
          layout="prev, pager, next"
          @current-change="handlePageChange"
        />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "JobsViews",
  data() {
    return {
      searchQuery: "",
      filter: {
        category: "",
        location: "",
        salaryRange: "",
        jobType: "",
      },
      sortOption: "newest",
      currentPage: 1,
      pageSize: 8,
      tagTypes: ["", "success", "info", "warning", "danger"],
      jobCategories: [
        { value: "it", label: "IT/互联网" },
        { value: "design", label: "设计/创意" },
        { value: "writing", label: "文案/写作" },
        { value: "marketing", label: "营销/推广" },
        { value: "education", label: "教育/培训" },
        { value: "service", label: "生活服务" },
      ],
      locations: [
        { value: "beijing", label: "北京" },
        { value: "shanghai", label: "上海" },
        { value: "guangzhou", label: "广州" },
        { value: "shenzhen", label: "深圳" },
        { value: "hangzhou", label: "杭州" },
        { value: "chengdu", label: "成都" },
      ],
      salaryRanges: [
        { value: "0-100", label: "100元/天以下" },
        { value: "100-300", label: "100-300元/天" },
        { value: "300-500", label: "300-500元/天" },
        { value: "500-800", label: "500-800元/天" },
        { value: "800+", label: "800元/天以上" },
      ],
      jobTypes: [
        { value: "full-time", label: "全职" },
        { value: "part-time", label: "兼职" },
        { value: "freelance", label: "自由职业" },
        { value: "internship", label: "实习" },
        { value: "remote", label: "远程" },
      ],
      sortOptions: [
        { value: "newest", label: "最新发布" },
        { value: "salary-high", label: "薪资最高" },
        { value: "salary-low", label: "薪资最低" },
      ],
      jobs: [
        {
          id: 1,
          title: "前端开发工程师",
          category: "it",
          salary: "¥500-800/天",
          location: "beijing",
          postTime: "1小时前",
          description:
            "负责公司官网前端开发工作，要求熟悉Vue.js框架，有响应式开发经验。",
          tags: ["Vue.js", "HTML5", "CSS3", "兼职"],
          type: "part-time",
          salaryValue: 650,
        },
        {
          id: 2,
          title: "UI设计师",
          category: "design",
          salary: "¥400-600/天",
          location: "shanghai",
          postTime: "2小时前",
          description: "负责移动端和Web端界面设计，有电商设计经验者优先。",
          tags: ["UI设计", "Photoshop", "长期"],
          type: "full-time",
          salaryValue: 500,
        },
        // 更多示例数据...
      ],
    };
  },
  computed: {
    filteredJobs() {
      let result = [...this.jobs];

      // 搜索过滤
      if (this.searchQuery) {
        const query = this.searchQuery.toLowerCase();
        result = result.filter(
          (job) =>
            job.title.toLowerCase().includes(query) ||
            job.description.toLowerCase().includes(query) ||
            job.tags.some((tag) => tag.toLowerCase().includes(query))
        );
      }

      // 分类过滤
      if (this.filter.category) {
        result = result.filter((job) => job.category === this.filter.category);
      }

      // 地点过滤
      if (this.filter.location) {
        result = result.filter((job) => job.location === this.filter.location);
      }

      // 薪资范围过滤
      if (this.filter.salaryRange) {
        const [min, max] = this.filter.salaryRange.split("-");
        if (max) {
          result = result.filter(
            (job) =>
              job.salaryValue >= parseInt(min) &&
              job.salaryValue <= parseInt(max)
          );
        } else {
          // 处理800+的情况
          result = result.filter((job) => job.salaryValue >= 800);
        }
      }

      // 工作类型过滤
      if (this.filter.jobType) {
        result = result.filter((job) => job.type === this.filter.jobType);
      }

      // 排序
      if (this.sortOption === "newest") {
        // 按发布时间排序（示例中简单处理）
        result.sort((a, b) => b.id - a.id);
      } else if (this.sortOption === "salary-high") {
        result.sort((a, b) => b.salaryValue - a.salaryValue);
      } else if (this.sortOption === "salary-low") {
        result.sort((a, b) => a.salaryValue - b.salaryValue);
      }

      return result;
    },
    paginatedJobs() {
      const start = (this.currentPage - 1) * this.pageSize;
      const end = start + this.pageSize;
      return this.filteredJobs.slice(start, end);
    },
  },
  methods: {
    handleSearch() {
      this.currentPage = 1;
      // 实际项目中这里可以调用API
      console.log("搜索:", this.searchQuery);
    },
    handleSearchClear() {
      this.searchQuery = "";
      this.handleSearch();
    },
    handleFilterChange() {
      this.currentPage = 1;
      // 实际项目中这里可以调用API
      console.log("筛选条件变化:", this.filter);
    },
    handleSortChange() {
      // 排序变化已经在计算属性中处理
      console.log("排序方式变化:", this.sortOption);
    },
    handlePageChange(page) {
      this.currentPage = page;
      window.scrollTo({ top: 0, behavior: "smooth" });
    },
    viewJobDetail(jobId) {
      this.$router.push(`/job/${jobId}`);
    },
    applyJob(jobId) {
      // 实际项目中这里可以调用API
      this.$message.success(`已申请职位ID: ${jobId}`);
      console.log("申请职位:", jobId);
    },
  },
};
</script>

<style scoped>
.jobs-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.search-filter-section {
  background: white;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 20px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.search-box {
  margin-bottom: 20px;
}

.filter-area {
  margin-top: 15px;
}

.job-list-section {
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.job-list-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.job-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
  margin-bottom: 20px;
}

.job-card {
  border: 1px solid #ebeef5;
  border-radius: 8px;
  padding: 20px;
  cursor: pointer;
  transition: all 0.3s;
}

.job-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.job-card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.job-card-header h3 {
  font-size: 18px;
  margin: 0;
}

.salary {
  color: #ff4d4f;
  font-weight: bold;
  font-size: 16px;
}

.job-meta {
  display: flex;
  gap: 15px;
  margin-bottom: 10px;
  font-size: 14px;
  color: #909399;
}

.job-meta i {
  margin-right: 5px;
}

.job-description {
  color: #606266;
  font-size: 14px;
  line-height: 1.6;
  margin-bottom: 15px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-overflow: ellipsis;
}

.job-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 15px;
}

.job-card-footer {
  display: flex;
  justify-content: flex-end;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}

@media (max-width: 768px) {
  .job-list {
    grid-template-columns: 1fr;
  }

  .job-list-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;
  }

  .filter-area .el-col {
    margin-bottom: 10px;
  }
}
</style>
