<template>
  <div class="register-container">
    <h1>注册</h1>
    <form @submit.prevent="register">
      <div class="form-group">
        <label for="phone">手机号</label>
        <input
          type="text"
          id="phone"
          v-model="form.phone"
          required
          placeholder="请输入手机号"
        />
        <span v-if="errors.phone" class="error">{{ errors.phone }}</span>
      </div>

      <div class="form-group">
        <label for="email">邮箱</label>
        <input
          type="email"
          id="email"
          v-model="form.email"
          required
          placeholder="请输入邮箱"
        />
        <span v-if="errors.email" class="error">{{ errors.email }}</span>
      </div>

      <div class="form-group">
        <label for="password">密码</label>
        <input
          type="password"
          id="password"
          v-model="form.password"
          required
          placeholder="请输入密码"
        />
        <span v-if="errors.password" class="error">{{ errors.password }}</span>
      </div>

      <div class="form-group">
        <label for="confirmPassword">确认密码</label>
        <input
          type="password"
          id="confirmPassword"
          v-model="form.confirmPassword"
          required
          placeholder="请确认密码"
        />
        <span v-if="errors.confirmPassword" class="error">{{
          errors.confirmPassword
        }}</span>
      </div>

      <div class="form-group">
        <button type="submit">注册</button>
      </div>
    </form>
  </div>
</template>

<script>
import { registerUser } from "../api/axios";

export default {
  data() {
    return {
      form: {
        phone: "",
        email: "",
        password: "",
        confirmPassword: "",
      },
      errors: {},
    };
  },
  methods: {
    register() {
      this.errors = {}; // 清空之前的错误信息

      // 验证手机号
      if (!this.form.phone) {
        this.errors.phone = "手机号不能为空";
      } else if (!/^\d{11}$/.test(this.form.phone)) {
        this.errors.phone = "请输入有效的手机号";
      }

      // 验证邮箱
      if (!this.form.email) {
        this.errors.email = "邮箱不能为空";
      } else if (!/^\S+@\S+\.\S+$/.test(this.form.email)) {
        this.errors.email = "请输入有效的邮箱地址";
      }

      // 验证密码
      if (!this.form.password) {
        this.errors.password = "密码不能为空";
      } else if (this.form.password.length < 6) {
        this.errors.password = "密码长度至少为6位";
      }

      // 验证确认密码
      if (!this.form.confirmPassword) {
        this.errors.confirmPassword = "确认密码不能为空";
      } else if (this.form.password !== this.form.confirmPassword) {
        this.errors.confirmPassword = "两次输入的密码不一致";
      }

      // 如果没有错误，提交注册
      if (Object.keys(this.errors).length === 0) {
        registerUser(this.form)
          .then((response) => {
            // 注册成功
            alert(response.data.message);
            this.form = {}; // 清空表单
          })
          .catch((error) => {
            // 注册失败
            if (error.response && error.response.data) {
              alert(error.response.data.message);
            } else {
              alert("注册失败，请稍后再试！");
            }
          });
      }
    },
  },
};
</script>

<style scoped>
.register-container {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
  background-color: #f9f9f9;
}

h1 {
  text-align: center;
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 15px;
}

label {
  display: block;
  margin-bottom: 5px;
}

input {
  width: 100%;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}

.error {
  color: red;
  font-size: 0.8rem;
}
</style>
