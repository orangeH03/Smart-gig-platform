<template>
  <div class="login-container">
    <h1>登录</h1>
    <form @submit.prevent="login">
      <div class="form-group">
        <label for="loginId">手机号/邮箱</label>
        <input
          type="text"
          id="loginId"
          v-model="form.loginId"
          required
          placeholder="请输入手机号或邮箱"
        />
        <span v-if="errors.loginId" class="error">{{ errors.loginId }}</span>
      </div>

      <div class="form-group">
        <label for="password">密码</label>
        <input
          type="password"
          id="password"
          v-model="form.password"
          required
          placeholder="请输入密码"
        />
        <span v-if="errors.password" class="error">{{ errors.password }}</span>
      </div>

      <div class="form-group">
        <button type="submit">登录</button>
      </div>
    </form>
    <div class="login-status">
      <p v-if="loginStatus">登录状态：{{ loginStatus }}</p>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      form: {
        loginId: "",
        password: "",
      },
      errors: {},
      loginStatus: "",
    };
  },
  methods: {
    login() {
      this.errors = {}; // 清空之前的错误信息

      // 验证登录信息
      if (!this.form.loginId) {
        this.errors.loginId = "登录账号不能为空";
      } else if (
        !/^\S+@\S+\.\S+$/.test(this.form.loginId) &&
        !/^\d{11}$/.test(this.form.loginId)
      ) {
        this.errors.loginId = "请输入有效的手机号或邮箱";
      }

      if (!this.form.password) {
        this.errors.password = "密码不能为空";
      } else if (this.form.password.length < 6) {
        this.errors.password = "密码长度至少为6位";
      }

      // 如果没有错误，模拟登录
      if (Object.keys(this.errors).length === 0) {
        console.log("登录信息：", this.form);
        this.loginStatus = "登录成功！";
        this.form = {}; // 清空表单
      }
    },
  },
};
</script>

<style scoped>
.login-container {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 8px;
  background-color: #f9f9f9;
}

h1 {
  text-align: center;
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 15px;
}

label {
  display: block;
  margin-bottom: 5px;
}

input {
  width: 100%;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}

.error {
  color: red;
  font-size: 0.8rem;
}

.login-status {
  margin-top: 20px;
  text-align: center;
}
</style>
