<template>
  <div class="home-container">
    <!-- 欢迎横幅 -->
    <div class="welcome-banner">
      <h1>欢迎来到智慧零工平台</h1>
      <p>连接企业与自由职业者的最佳平台，快速找到您需要的服务或工作机会</p>
      <div class="banner-actions">
        <el-button
          type="primary"
          size="medium"
          @click="$router.push('/post-job')"
          >发布任务</el-button
        >
        <el-button plain size="medium" @click="$router.push('/jobs')"
          >寻找工作</el-button
        >
      </div>
    </div>

    <!-- 平台特色 -->
    <div class="features-section">
      <h2 class="section-title">平台特色</h2>
      <div class="features-grid">
        <div class="feature-card">
          <i class="icon-feature1"></i>
          <h3>高效匹配</h3>
          <p>智能算法精准匹配企业与零工需求</p>
        </div>
        <div class="feature-card">
          <i class="icon-feature2"></i>
          <h3>安全可靠</h3>
          <p>严格审核机制保障双方权益</p>
        </div>
        <div class="feature-card">
          <i class="icon-feature3"></i>
          <h3>灵活用工</h3>
          <p>按需用工，降低企业成本</p>
        </div>
      </div>
    </div>

    <!-- 任务卡片 -->
    <div class="jobs-section">
      <h2 class="section-title">最新任务</h2>
      <div class="jobs-grid">
        <div
          class="job-card"
          v-for="job in jobs"
          :key="job.id"
          @click="$router.push(`/job/${job.id}`)"
        >
          <h3>{{ job.title }}</h3>
          <p>{{ job.description }}</p>
          <div class="job-card-footer">
            <span>薪资：{{ job.salaryRange }}</span>
            <span>地点：{{ job.location }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 右下角浮动按钮 -->
    <div class="float-action">
      <el-button
        type="primary"
        circle
        size="medium"
        @click="$router.push('/post-job')"
      >
        <i class="icon-plus"></i>
      </el-button>
    </div>
  </div>
</template>

<script>
export default {
  name: "HomeViews",
  data() {
    return {
      jobs: [
        {
          id: 1,
          title: "前端开发任务",
          description: "需要一个 Vue.js 专家来开发一个新项目",
          salaryRange: "8000-15000",
          location: "北京",
        },
        {
          id: 2,
          title: "UI/UX 设计任务",
          description: "设计一个新产品的用户界面",
          salaryRange: "7000-12000",
          location: "上海",
        },
        {
          id: 3,
          title: "后端开发任务",
          description: "需要一个 Node.js 开发者来优化后端服务",
          salaryRange: "9000-16000",
          location: "广州",
        },
      ],
    };
  },
};
</script>

<style scoped>
.home-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.welcome-banner {
  background: linear-gradient(135deg, #1e88e5, #0d47a1);
  color: white;
  padding: 40px;
  border-radius: 8px;
  margin-bottom: 40px;
  text-align: center;
}

.welcome-banner h1 {
  font-size: 32px;
  margin-bottom: 15px;
}

.welcome-banner p {
  font-size: 16px;
  margin-bottom: 25px;
  opacity: 0.9;
}

.banner-actions {
  display: flex;
  justify-content: center;
  gap: 20px;
}

.features-section {
  margin-bottom: 40px;
}

.section-title {
  font-size: 24px;
  margin-bottom: 20px;
  color: #333;
  text-align: center;
}

.features-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}

.feature-card {
  background: white;
  padding: 30px;
  border-radius: 8px;
  text-align: center;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.feature-card i {
  font-size: 40px;
  color: var(--primary-color);
  margin-bottom: 15px;
  display: block;
}

.feature-card h3 {
  font-size: 18px;
  margin-bottom: 10px;
}

.feature-card p {
  color: var(--text-light);
  font-size: 14px;
}

.jobs-section {
  margin-bottom: 40px;
}

.jobs-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}

.job-card {
  background: white;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  cursor: pointer;
  transition: transform 0.3s ease;
}

.job-card:hover {
  transform: translateY(-5px);
}

.job-card h3 {
  font-size: 18px;
  margin-bottom: 10px;
}

.job-card p {
  font-size: 14px;
  margin-bottom: 15px;
}

.job-card-footer {
  display: flex;
  justify-content: space-between;
  font-size: 14px;
  color: #666;
}

.float-action {
  position: fixed;
  right: 40px;
  bottom: 40px;
  z-index: 100;
}

.float-action button {
  width: 56px;
  height: 56px;
  font-size: 24px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}
</style>
