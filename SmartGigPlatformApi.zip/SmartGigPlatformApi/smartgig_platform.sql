-- 创建用户表（user）
CREATE TABLE user (
                      user_id INT AUTO_INCREMENT PRIMARY KEY,
                      user_name VARCHAR(50) NOT NULL,
                      password VARCHAR(100) NOT NULL,
                      phone VARCHAR(20),
                      email VARCHAR(50),
                      user_type INT NOT NULL CHECK (user_type IN (1, 2, 3)),
                      is_certified BOOLEAN DEFAULT FALSE,
                      credit_score INT DEFAULT 0
);

-- 创建任务表（task）
CREATE TABLE task (
                      task_id INT AUTO_INCREMENT PRIMARY KEY,
                      title VARCHAR(100) NOT NULL,
                      description TEXT,
                      salary_range VARCHAR(50),
                      location VARCHAR(100),
                      start_time DATETIME,
                      end_time DATETIME,
                      status INT NOT NULL CHECK (status IN (1, 2, 3)),
                      creator_id INT NOT NULL,
                      FOREIGN KEY (creator_id) REFERENCES user(user_id)
);

-- 创建评价表（evaluation）
CREATE TABLE evaluation (
                            eval_id INT AUTO_INCREMENT PRIMARY KEY,
                            task_id INT NOT NULL,
                            from_user_id INT NOT NULL,
                            to_user_id INT NOT NULL,
                            quality_score INT CHECK (quality_score BETWEEN 1 AND 5),
                            efficiency_score INT CHECK (efficiency_score BETWEEN 1 AND 5),
                            honesty_score INT CHECK (honesty_score BETWEEN 1 AND 5),
                            comment TEXT,
                            FOREIGN KEY (task_id) REFERENCES task(task_id),
                            FOREIGN KEY (from_user_id) REFERENCES user(user_id),
                            FOREIGN KEY (to_user_id) REFERENCES user(user_id)
);

-- 创建课程表（course）
CREATE TABLE course (
                        course_id INT AUTO_INCREMENT PRIMARY KEY,
                        title VARCHAR(100) NOT NULL,
                        description TEXT,
                        category VARCHAR(50)
);

-- 创建用户课程关联表（user_course）
CREATE TABLE user_course (
                             user_course_id INT AUTO_INCREMENT PRIMARY KEY,
                             user_id INT NOT NULL,
                             course_id INT NOT NULL,
                             progress FLOAT CHECK (progress BETWEEN 0 AND 1),
                             FOREIGN KEY (user_id) REFERENCES user(user_id),
                             FOREIGN KEY (course_id) REFERENCES course(course_id)
);

-- 创建举报表（report）
CREATE TABLE report (
                        report_id INT AUTO_INCREMENT PRIMARY KEY,
                        reporter_id INT NOT NULL,
                        reported_id INT NOT NULL,
                        content TEXT,
                        status INT NOT NULL CHECK (status IN (1, 2)),
                        FOREIGN KEY (reporter_id) REFERENCES user(user_id),
                        FOREIGN KEY (reported_id) REFERENCES user(user_id)
);