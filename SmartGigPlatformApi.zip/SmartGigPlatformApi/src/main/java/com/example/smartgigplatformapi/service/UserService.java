package com.example.smartgigplatformapi.service;

import com.example.smartgigplatformapi.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 李长焘
* @description 针对表【user】的数据库操作Service
* @createDate 2025-05-16 17:29:51
*/
public interface UserService extends IService<User> {

    User findByUserName(String userName);

    void register(String userName, String password, String phone, String email, Integer userType);
}
