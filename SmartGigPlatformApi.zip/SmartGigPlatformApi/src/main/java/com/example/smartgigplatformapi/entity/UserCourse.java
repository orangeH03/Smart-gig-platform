package com.example.smartgigplatformapi.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName user_course
 */
@TableName(value ="user_course")
@Data
public class UserCourse implements Serializable {
    /**
     * 
     */
    @TableId(type = IdType.AUTO)
    private Integer userCourseId;

    /**
     * 
     */
    private Integer userId;

    /**
     * 
     */
    private Integer courseId;

    /**
     * 
     */
    private Double progress;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}