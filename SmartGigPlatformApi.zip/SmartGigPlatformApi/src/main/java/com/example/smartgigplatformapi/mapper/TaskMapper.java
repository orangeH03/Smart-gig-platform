package com.example.smartgigplatformapi.mapper;

import com.example.smartgigplatformapi.entity.Task;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
* @author 李长焘
* @description 针对表【task】的数据库操作Mapper
* @createDate 2025-05-16 17:32:41
* @Entity com.example.smartgigplatformapi.entity.Task
*/
@Mapper
public interface TaskMapper extends BaseMapper<Task> {

}




