package com.example.smartgigplatformapi.controller;

import com.example.smartgigplatformapi.common.Result;
import com.example.smartgigplatformapi.entity.User;
import com.example.smartgigplatformapi.mapper.UserMapper;
import com.example.smartgigplatformapi.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/user")
public class UserController {
    @Autowired
    private UserService  userService;

    @PostMapping("/register")
    public Result register(@RequestBody User user) {
        // 校验用户名是否为空
        if (user.getUserName() == null || user.getUserName().isEmpty()) {
            return Result.error("用户名不能为空");
        }

        // 查询用户名是否存在
        User existingUser = userService.findByUserName(user.getUserName());

        if (existingUser != null) {
            // 用户名已存在
            return Result.error("用户名已被占用");
        }

        // 执行注册
        userService.register(
                user.getUserName(),
                user.getPassword(),
                user.getPhone(),
                user.getEmail(),
                user.getUserType()
        );

        return Result.success("注册成功");
    }
}
