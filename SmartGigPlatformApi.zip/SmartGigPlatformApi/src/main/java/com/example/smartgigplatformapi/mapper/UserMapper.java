package com.example.smartgigplatformapi.mapper;

import com.example.smartgigplatformapi.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
* @author 李长焘
* @description 针对表【user】的数据库操作Mapper
* @createDate 2025-05-16 17:29:51
* @Entity com.example.smartgigplatformapi.entity.User
*/
@Mapper
public interface UserMapper extends BaseMapper<User> {

    User findByUserName(String userName);

    void register(
            @Param("userName") String userName,
            @Param("password") String password,
            @Param("phone") String phone,
            @Param("email") String email,
            @Param("userType") Integer userType
    );

}




