package com.example.smartgigplatformapi.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.smartgigplatformapi.entity.Task;
import com.example.smartgigplatformapi.service.TaskService;
import com.example.smartgigplatformapi.mapper.TaskMapper;
import org.springframework.stereotype.Service;

/**
* @author 李长焘
* @description 针对表【task】的数据库操作Service实现
* @createDate 2025-05-16 17:32:41
*/
@Service
public class TaskServiceImpl extends ServiceImpl<TaskMapper, Task>
    implements TaskService{

}




