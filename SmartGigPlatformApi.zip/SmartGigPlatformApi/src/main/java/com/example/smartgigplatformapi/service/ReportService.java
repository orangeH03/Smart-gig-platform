package com.example.smartgigplatformapi.service;

import com.example.smartgigplatformapi.entity.Report;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 李长焘
* @description 针对表【report】的数据库操作Service
* @createDate 2025-05-16 17:32:41
*/
public interface ReportService extends IService<Report> {

}
