package com.example.smartgigplatformapi.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.smartgigplatformapi.entity.User;
import com.example.smartgigplatformapi.service.UserService;
import com.example.smartgigplatformapi.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
* @author 李长焘
* @description 针对表【user】的数据库操作Service实现
* @createDate 2025-05-16 17:29:51
*/
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User>
    implements UserService{

    @Autowired
    private UserMapper userMapper;
    @Override
    public User findByUserName(String user_name) {
        return userMapper.findByUserName(user_name);
    }

    @Override
    public void register(String userName, String password, String phone, String email, Integer userType) {
        userMapper.register(userName, password, phone, email, userType);
    }
}




