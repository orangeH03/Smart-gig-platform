package com.example.smartgigplatformapi.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName evaluation
 */
@TableName(value ="evaluation")
@Data
public class Evaluation implements Serializable {
    /**
     * 
     */
    @TableId(type = IdType.AUTO)
    private Integer evalId;

    /**
     * 
     */
    private Integer taskId;

    /**
     * 
     */
    private Integer fromUserId;

    /**
     * 
     */
    private Integer toUserId;

    /**
     * 
     */
    private Integer qualityScore;

    /**
     * 
     */
    private Integer efficiencyScore;

    /**
     * 
     */
    private Integer honestyScore;

    /**
     * 
     */
    private String comment;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}