package com.example.smartgigplatformapi.common;

public class Result {
    private int code; //编码200 400
    private String message; //成功 失败
    private Object data; //数据
    public static Result error(Object data){
        return result(400, "失败", data);
    }
    public static Result success(){
        return result(200, "成功", null);
    }
    public static Result success(Object data){
        return result(200, "成功", data);
    }

    private static Result result(int code,String message,Object data) {
        Result res = new Result();
        res.setData(data);
        res.setMessage(message);
        res.setCode(code);
        return res;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "Result{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", data=" + data +
                '}';
    }
}