package com.example.smartgigplatformapi.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.smartgigplatformapi.entity.Course;
import com.example.smartgigplatformapi.service.CourseService;
import com.example.smartgigplatformapi.mapper.CourseMapper;
import org.springframework.stereotype.Service;

/**
* @author 李长焘
* @description 针对表【course】的数据库操作Service实现
* @createDate 2025-05-16 17:32:41
*/
@Service
public class CourseServiceImpl extends ServiceImpl<CourseMapper, Course>
    implements CourseService{

}




